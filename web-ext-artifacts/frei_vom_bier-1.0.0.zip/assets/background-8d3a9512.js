import{b as e}from"./browser-polyfill-bb39cfe9.js";e.runtime.onInstalled.addListener(()=>{console.log("Extension installed")});
